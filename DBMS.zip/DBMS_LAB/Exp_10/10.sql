create table MEDICINE(Mid int not null primary key, Medname varchar(50), Price float, Quantity int );

insert into MEDICINE values(1, 'Crocin', 500.6, 25);
insert into MEDICINE values(2, 'Calpol', 355.9, 30);


create table NEW_ORDER(Mid int not null primary key, ODate date, New_Quantity int);



DELIMITER //
create trigger Less_stock_Medicine after update on MEDICINE for each row begin if NEW.Quantity < 20 then insert into NEW_ORDER(Mid, ODate, New_Quantity) values(NEW.Mid, CURDATE(), NEW.Quantity); end if;
end; //
mysql> delimiter ;







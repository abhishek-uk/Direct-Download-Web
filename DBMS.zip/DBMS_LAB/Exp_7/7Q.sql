mysql> select * from Employee1 UNION select * from Employee2;


mysql> select * from Employee1 UNION ALL select * from Employee2;


mysql> select * from Employee1 where Name in (select Name from Employee2);
mysql> select distinct Employee1.* from Employee1 inner join Employee2 on Employee1.Name = Employee2.Name;


mysql> select * from Employee1 where Name not in (select Name from Employee2);
mysql> select * from Employee1 where Name not in (select Name from Employee2);


select BOOK.Title as 'Books in english',  BOOK.Language_id from BOOK join LANGUAGE on BOOK.Language_id = LANGUAGE.Language_id where LANGUAGE.Name = "English";
 
 
select MEMBER.Name, BOOK.Title, BOOK_ISSUE.Date_of_issue from BOOK_ISSUE join BOOK on BOOK.Book_id = BOOK_ISSUE.Book_id JOIN MEMBER on MEMBER.Member_id = BOOK_ISSUE.Member_id where MEMBER.Date_of_join > '2022-01-01';
 
 
select count(BOOK.Title) as "No.of books", AUTHOR.Name as 'Author Name' from BOOK_AUTHOR join BOOK on BOOK.Book_id = BOOK_AUTHOR.Book_id join AUTHOR on AUTHOR.Author_id = BOOK_AUTHOR.Author_id group by AUTHOR.Name;


select PUBLISHER.Name, count(BOOK.Publisher_id) from PUBLISHER join BOOK on BOOK.Publisher_id = PUBLISHER.Publisher_id group by(PUBLISHER.Name);


select BOOK.Title, BOOK_ISSUE.Date_of_issue from BOOK_ISSUE join BOOK on BOOK.Book_id = BOOK_ISSUE.Book_id join BOOK_RETURN on BOOK_RETURN.Issue_id = BOOK_ISSUE.Issue_id where BOOK_RETURN.Actual_date_of_return is NULL;

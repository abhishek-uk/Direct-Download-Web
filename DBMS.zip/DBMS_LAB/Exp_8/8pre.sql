INSERT INTO PUBLISHER (Publisher_id, Name, Address) VALUES (4, 'Abu', 'Kochi'),  (5, 'Abraham', 'Trissur'),        (6, 'Vinu', 'Panoor'),        (7, 'Itty', 'Feroke'),        (8, 'Anoop', 'Feroke'),
 (9, 'Antony', 'Tirur'),        (10, 'Achudan', 'Adoor');
 
 

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (1, 'War and Peace', 2, 1499, 1, '2020-05-15', 5, 'Available');

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (4, 'To Kill a Mockingbird', 2, 799, 3, '2018-07-10', 3, 'Available');

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (7, 'Pride and Prejudice', 2, 899, 2, '2019-03-08', 5, 'Available');

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (8, 'The Alchemist', 5, 399, 5, '2022-08-15', 2, 'Available');

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (9, 'Inferno', 2, 1099, 1, '2016-11-20', 4, 'Available');

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (10, 'The Catcher in the Rye', 2, 799, 4, '2020-02-05', 3, 'Available');

INSERT INTO BOOK (Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status)
VALUES (11, 'To Kill a Mockingbird', 2, 799, 3, '2018-07-10', 3, 'Available');



-- Insert sample data into the BOOK_AUTHOR table
INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (1, 1, 1); -- Book 1 is authored by Author 1

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (2, 2, 2); -- Book 2 is authored by Author 2

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (3, 3, 3); -- Book 3 is authored by Author 3

-- You can continue to insert more rows with random data as needed.


-- Insert more random data into the BOOK_AUTHOR table
INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (4, 4, 2); -- Book 4 is authored by Author 2

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (5, 5, 1); -- Book 5 is authored by Author 1

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (6, 6, 3); -- Book 6 is authored by Author 3

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (7, 7, 3); -- Book 7 is authored by Author 3

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (8, 8, 2); -- Book 8 is authored by Author 2

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (9, 9, 1); -- Book 9 is authored by Author 1

INSERT INTO BOOK_AUTHOR (BA_id, Book_id, Author_id)
VALUES (10, 10, 2); -- Book 10 is authored by Author 2

-- You can continue to insert more rows with random data as needed.




-- Insert sample data into the LATE_FEE_RULE table
INSERT INTO LATE_FEE_RULE (id, FromDays, ToDays, Amount)
VALUES (1, 1, 7, 50); -- Late fee rule for 1 to 7 days

INSERT INTO LATE_FEE_RULE (id, FromDays, ToDays, Amount)
VALUES (2, 8, 14, 100); -- Late fee rule for 8 to 14 days

INSERT INTO LATE_FEE_RULE (id, FromDays, ToDays, Amount)
VALUES (3, 15, 30, 200); -- Late fee rule for 15 to 30 days

-- You can continue to insert more rules with random data as needed.


-- Insert more random data into the LATE_FEE_RULE table
INSERT INTO LATE_FEE_RULE (id, FromDays, ToDays, Amount)
VALUES (4, 31, 60, 300); -- Late fee rule for 31 to 60 days

INSERT INTO LATE_FEE_RULE (id, FromDays, ToDays, Amount)
VALUES (5, 61, 90, 500); -- Late fee rule for 61 to 90 days

INSERT INTO LATE_FEE_RULE (id, FromDays, ToDays, Amount)
VALUES (6, 91, 999, 1000); -- Late fee rule for 91 days or more

-- You can continue to insert more rules with different data as needed.









-- Insert sample data into the BOOK_ISSUE table
INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (1, '2023-11-10', 1, 1, '2023-11-20', 'Issued', 1); -- Book 1 issued to Member 1

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (2, '2023-11-12', 2, 2, '2023-11-22', 'Issued', 2); -- Book 2 issued to Member 2

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (3, '2023-11-15', 3, 3, '2023-11-25', 'Issued', 3); -- Book 3 issued to Member 3

-- You can continue to insert more rows with random data as needed.


-- Insert more random data into the BOOK_ISSUE table
INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (4, '2023-11-18', 4, 4, '2023-11-28', 'Issued', 4); -- Book 4 issued to Member 4

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (5, '2023-11-20', 5, 5, '2023-11-30', 'Issued', 5); -- Book 5 issued to Member 5

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (6, '2023-11-22', 6, 6, '2023-12-02', 'Issued', 6); -- Book 6 issued to Member 6

-- You can continue to insert more rows with different book issues as needed.


-- Insert more random data into the BOOK_ISSUE table
INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (7, '2023-11-24', 7, 1, '2023-12-04', 'Issued', 3); -- Book 7 issued to Member 1

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (8, '2023-11-26', 8, 2, '2023-12-06', 'Issued', 2); -- Book 8 issued to Member 2

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (9, '2023-11-28', 9, 3, '2023-12-08', 'Issued', 1); -- Book 9 issued to Member 3

INSERT INTO BOOK_ISSUE (Issue_id, Date_of_issue, Book_id, Member_id, Expected_date_of_Return, Status, id)
VALUES (10, '2023-11-30', 10, 4, '2023-12-10', 'Issued', 2); -- Book 10 issued to Member 4

-- You can continue to insert more rows with different book issues as needed.









-- Insert sample data into the BOOK_RETURN table
INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (1, 1, '2023-11-18', 2, 100); -- Book return for Issue_id 1

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (2, 2, '2023-11-26', 4, 200); -- Book return for Issue_id 2

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (3, 3, '2023-12-01', 6, 300); -- Book return for Issue_id 3

-- You can continue to insert more rows with random data as needed.


-- Insert more random data into the BOOK_RETURN table
INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (4, 4, '2023-11-29', 1, 50); -- Book return for Issue_id 4

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (5, 5, '2023-12-03', 3, 150); -- Book return for Issue_id 5

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (6, 6, '2023-12-05', 3, 150); -- Book return for Issue_id 6

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (7, 7, '2023-12-06', 2, 100); -- Book return for Issue_id 7

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (8, 8, '2023-12-10', 4, 200); -- Book return for Issue_id 8

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (9, 9, '2023-12-12', 4, 200); -- Book return for Issue_id 9

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (10, 10, '2023-12-15', 5, 250); -- Book return for Issue_id 10

-- You can continue to insert more rows with different book return data as needed.




-- Insert more data into the BOOK_RETURN table with empty Actual_date_of_return
INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (11, 1, NULL, NULL, NULL); -- Empty Actual_date_of_return for Issue_id 1

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (12, 2, NULL, NULL, NULL); -- Empty Actual_date_of_return for Issue_id 2

INSERT INTO BOOK_RETURN (BR_id, Issue_id, Actual_date_of_return, LateDays, LateFee)
VALUES (13, 3, NULL, NULL, NULL); -- Empty Actual_date_of_return for Issue_id 3

-- You can continue to insert more rows with empty Actual_date_of_return as needed.


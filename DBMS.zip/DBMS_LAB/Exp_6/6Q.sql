-- a,
select Emp_name, Job, Hiredate from EMP where Hiredate between "1990-02-20" and "1998-05-01" order by Hiredate;

--b,
select Emp_name as Employee, Salary as "Monthly Salary" from EMP where (Salary between 5000 and 12000) and (dep_no = 2 or dep_no = 4);

--c,
select Emp_name, Hiredate from EMP where Hiredate like "1994-%";

--d,
select Emp_name, Salary, Comm from EMP where (Comm > 0) order by Salary DESC, Comm DESC;

--e,
select EMP.Emp_name, EMP.Job, EMP.Dep_no from EMP where (EMP.Dep_no = (select DEPT.Department_id from DEPT where DEPT.Manager_id is NULL))

--f,
select Emp_name as Name, LENGTH(Emp_name) as Name_length from EMP where Emp_name like "J%" or Emp_name LIKE "A%" or Emp_name like "M%";

--g,
select Job, count(*) from EMP group by Job;

--h,
SELECT DEPT.Department_name AS Name, DEPT.Loc AS Location, COUNT(EMP.Emp_no) AS "Number of People", ROUND(AVG(EMP.Salary), 2) AS Salary FROM DEPT LEFT JOIN EMP ON DEPT.Department_id = EMP.Dep_no GROUP BY DEPT.Department_name, DEPT.Loc;

--i,
SELECT EMP.Emp_name, DEPT.Department_name AS Department_Name FROM EMP INNER JOIN DEPT ON EMP.Dep_no = DEPT.Department_id WHERE DEPT.Department_id IN (SELECT Dep_no FROM EMP GROUP BY Dep_no HAVING COUNT(*) >= 3 ) ORDER BY DEPT.Department_name, EMP.Emp_name;


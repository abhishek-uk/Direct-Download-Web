create table DEPT(Department_id int not null primary key, Department_name varchar(50), Manager_id int, Loc varchar(50));

insert into DEPT(Department_id, Department_name, Manager_id, Loc) values(1,"Administration",2,"Boston");
insert into DEPT(Department_id, Department_name, Manager_id, Loc) values(2,"Marketing",1,"Boston");
insert into DEPT(Department_id, Department_name, Manager_id, Loc) values(3,"Purchase",8,"perryridge");
insert into DEPT(Department_id, Department_name, Manager_id, Loc) values(4,"Programming",7,"Hudson");
insert into DEPT(Department_id, Department_name, Loc) values(5,"HR","Hudson");


create table EMP(Emp_no int not null primary key, Emp_name varchar(50), Job varchar(50), Hiredate date, Salary int, Comm int, Dep_no int);

insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(1,"Steven","Marketing","1995-01-21",24000,NULL,2);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(2,"Neena","FI_ACCOUNT","1987-02-06",34000,NULL,1);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(3,"Lex","FI_MGR","1980-01-06",240000,NULL,1);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(4,"Alexander","Sa_Rep","1987-06-06",20000,NULL,4);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(5,"Bruce","IT_PROG","1990-07-06",24000,NULL,4);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(6,"David","IT_PROG","1991-09-06",22000,NULL,4);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(7,"vipin","IT_PROG","1987-11-06",28000,NULL,4);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(8,"Diana","Pur_Man","1987-01-26",24000,NULL,3);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(9,"John","FI_ACCOUNT","1992-12-01",24000,NULL,1);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(10,"ismael","clerk","1994-03-29",4000,NULL,3);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(11,"Mathew","CLERK","1992-08-12",46000,200,3);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(12,"Hayes","Marketing","1998-04-21",14000,1000,2);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(13,"sarun","Marketing","1993-05-18",18000,NULL,2);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(14,"Henin","FI_MGR","1980-08-06",240000,NULL,1);
insert into EMP(Emp_no, Emp_name, Job, Hiredate, Salary, Comm, Dep_no) values(15,"Greesh","Clerk","1980-08-06",240000,NULL,5);


alter table DEPT add foreign key(Manager_id) references EMP(Emp_no);
alter table EMP add foreign key(Dep_no) references DEPT(Department_id);





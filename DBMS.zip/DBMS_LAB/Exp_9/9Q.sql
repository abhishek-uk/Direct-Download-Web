create view Available_Books as select * from BOOK where Status = 'Available';



update Available_Books set MRP = MRP * 1.1  where Book_id = 5;

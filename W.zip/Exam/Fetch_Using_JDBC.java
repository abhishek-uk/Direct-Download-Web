import java.sql.*;

class Fetch_Using_JDBC {
    public static void main(String args[]) {
        try {
            String dbURL = "jdbc:mysql://localhost:3306/Student";
            String username = "root";
            String passward = "123";
            Connection myConnection = DriverManager.getConnection(dbURL, username, passward);
            Statement myStatement = myConnection.createStatement();
            ResultSet myResultSet = myStatement.executeQuery("select * from Student");
            while (myResultSet.next()) {
                System.out.println("Student Full name: " + myResultSet.getString("First_name")
                        + myResultSet.getString("Last_name"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
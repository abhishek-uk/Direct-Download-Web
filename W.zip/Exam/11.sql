create table STUDENT(Roll_no int not null primary key, Name varchar(50), Mark float, Status varchar(50));

insert into STUDENT(Roll_no, Name, Mark, Status) values(1, "RAM", 60, "Pass");
insert into STUDENT(Roll_no, Name, Mark) values(2, "Seema", 40),(3, "Siya", 30), (4, "John", 20);

CREATE PROCEDURE UpdateStudentStatus()
begin
UPDATE STUDENT
 set Status = CASE
 WHEN Mark > 35 THEN 'Pass'
 ELSE 'Fail'
 END;
 END;
 //

 DELIMITER ;

 CALL UpdateStudentStatus();
 
 

select Emp_name, Job, Hiredate from EMP where Hiredate between "1990-02-20" and "1998-05-01" order by Hiredate;


select Emp_name as Employee, Salary as "Monthly Salary" from EMP where (Salary between 5000 and 12000) and (dep_no = 2 or dep_no = 4);


select Emp_name, Hiredate from EMP where Hiredate like "1994-%";


select Emp_name, Salary, Comm from EMP where (Comm > 0) order by Salary DESC, Comm DESC;




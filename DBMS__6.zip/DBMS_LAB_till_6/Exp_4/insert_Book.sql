insert into BOOK(Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status) values(1, "Jaws", 2, 500, 3, '2000-10-15', 5, "Availble");

insert into BOOK(Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status) values(2, "Dune", 3, 200, 2, '2006-06-25', 0, "Unavailble");

insert into BOOK(Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status) values(3, "Macbeth", 2, 899, 1, '1985-03-24', 10, "Availble");

insert into BOOK(Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status) values(4, "Cut", 1, 449, 3, '2010-08-06', 30, "Availble");

insert into BOOK(Book_id, Title, Language_id, MRP, Publisher_id, Published_date, Volume, Status) values(5, "Goldfinger", 2, 7899, 1, '2021-12-28', 2, "Availble");


create database Abhishek_Lib_Manag;
use Abhishek_Lib_Manag;



CREATE TABLE AUTHOR( Author_id int NOT NULL PRIMARY KEY, Name varchar(50), Email varchar(50), Phone_No int, Status varchar(50));
CREATE TABLE PUBLISHER(Publisher_id int NOT NULL PRIMARY KEY, Name varchar(50), Address varchar(50));
CREATE TABLE MEMBER( Member_id int NOT NULL PRIMARY KEY, Name varchar(50), Branch_code varchar(50), Roll_no int, Phone_no int,  Email_id varchar(50), Date_of_join DATE,  Status varchar(50));
CREATE TABLE LANGUAGE(Language_id int NOT NULL PRIMARY KEY, Name varchar(50));
CREATE TABLE LATE_FEE_RULE(id int NOT NULL PRIMARY KEY, FromDays DATE, ToDays DATE, Amount int );


CREATE TABLE BOOK(Book_id int NOT NULL PRIMARY KEY, Title varchar(50), Language_id int, MRP int, Publisher_id int, Published_date date, Volume int, Status varchar(50), FOREIGN KEY (Language_id) REFERENCES LANGUAGE(Language_id), FOREIGN KEY (Publisher_id) REFERENCES PUBLISHER(Publisher_id));
CREATE TABLE BOOK_AUTHOR(BA_id int NOT NULL PRIMARY KEY,Book_id int, Author_id int, FOREIGN KEY (Book_id) REFERENCES BOOK(Book_id), FOREIGN KEY (Author_id) REFERENCES AUTHOR(Author_id));
CREATE TABLE BOOK_ISSUE(Issue_id int NOT NULL PRIMARY KEY, Date_of_issue date, Book_id int, Member_id int, Expected_date_of_Return date, Status varchar(50), id int, FOREIGN KEY (Book_id) REFERENCES BOOK(Book_id), FOREIGN KEY (Member_id) REFERENCES MEMBER(Member_id));
CREATE TABLE BOOK_RETURN(BR_id int NOT NULL PRIMARY KEY, Issue_id int, Actual_date_of_return date, LateDays int, LateFee int, FOREIGN KEY (Issue_id) REFERENCES BOOK_ISSUE(Issue_id));

ALTER TABLE BOOK_ISSUE ADD FOREIGN KEY (id) REFERENCES LATE_FEE_RULE(id);




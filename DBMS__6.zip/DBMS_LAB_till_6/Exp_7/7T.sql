create table Employee1(Id int not null primary key, Name varchar(50), Department varchar(50), Salary int, Year_of_Experience int);

insert into Employee1(Id, Name, Department, Salary, Year_of_Experience) values(1, "Aakash Singh","Development", 72000, 2);
insert into Employee1(Id, Name, Department, Salary, Year_of_Experience) values(2, "Abhishek Pawar", "Production", 45000, 1);
insert into Employee1(Id, Name, Department, Salary, Year_of_Experience) values(3, "Pranav Deshmukh", "HR", 59900, 3);
insert into Employee1(Id, Name, Department, Salary, Year_of_Experience) values(4, "Shubham Mahale", "Accounts", 57000, 2);





create table Employee2(Id int not null primary key, Name varchar(50), Department varchar(50), Salary int, Year_of_Experience int);

insert into Employee2(Id, Name, Department, Salary, Year_of_Experience) values(1, "Prashant Wagh", "R&D", 49000, 1);
insert into Employee2(Id, Name, Department, Salary, Year_of_Experience) values(2, "Abhishek Pawar", "Production", 45000, 1);
insert into Employee2(Id, Name, Department, Salary, Year_of_Experience) values(3, "Gautam Jain", "Development", 56000, 4);
insert into Employee2(Id, Name, Department, Salary, Year_of_Experience) values(4, "Shubham Mahale", "Accounts", 57000, 2);

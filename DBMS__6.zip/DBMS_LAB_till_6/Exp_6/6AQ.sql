insert into MEMBER values(1, "James", "CSE", 23, 2345678, "james@gmail.com", "2000-02-19", "Online");
insert into MEMBER values(2, "John", "CE", 33, 2343478, "john@gmail.com", "1406-02-19", "Online");
insert into MEMBER values(3, "Thomas", "EC", 12, 2345678, "thomas@gmail.com", "2234-07-19", "Online");
insert into MEMBER values(4, "Michael", "ME", 03, 2345678, "michael@gmail.com", "1244-01-19", "Offline");
insert into MEMBER values(5, "Jack", "EC", 43, 2345678, "jack@gmail.com", "2015-02-12", "Busy");
insert into MEMBER values(6, "Robert", "CSE", 15, 2345678, "robert@gmail.com", "2010-03-19", "Online");



--a,
select * from MEMBER order by Name;

--b,
select Title, MRP from BOOK order by mrp DESC;

--c
SELECT Branch_code, COUNT(Branch_code) AS Number_of_Members FROM MEMBER GROUP BY Branch_code;

--d
SELECT Branch_code, COUNT(Member_id) AS Number_of_Members FROM MEMBER GROUP BY Branch_code ORDER BY Number_of_Members ASC;

--e
SELECT Name, Phone_no, Email_id FROM MEMBER WHERE Branch_code = 'CSE' ORDER BY Roll_no ASC;

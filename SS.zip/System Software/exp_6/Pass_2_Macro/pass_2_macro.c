#include<stdio.h>
#include<string.h>

void main(){
    char macros[20][10], label[20], opcode[20], operand[20];
    int i, j, n, m = 0;
    FILE *Fp1, *Fp[10], *Fp2;
    Fp1 = fopen("input.txt", "r");
    Fp2 = fopen("macro_out.txt", "w");
    fscanf(Fp1, "%s%s%s", label, opcode, operand);
    printf("before while\n\n\t %s",opcode);                                                          //
    while(strcmp(opcode, "END") != 0){
        printf("\t\t\tfirst while %s", opcode);
        if(!strcmp(opcode, "CALL")){
            printf("Here callllll.................................");
            Fp[m] = fopen(operand, "r");
            printf("After file created ");                                                         //
            m++;
            fscanf(Fp[m-1], "%s%s%s", label, opcode, operand);
            printf("after before while inside if that inside while");                                                         //
            while(!feof(Fp[m-1])){
                printf(" inside small while - Top");                                                         //
                // fprintf(Fp2, "%s\t%s\t%s\n", label, opcode, operand);
                // fscanf(Fp[m-1], "%s%s%s", label, opcode, operand);
                printf(" inside small while - last");                                                         //
            }
            printf("inside if \n");                                                         //
        }else{
            fprintf(Fp2, "%s\t%s\t%s\n", label, opcode, operand);
            printf("else case \n");                                                         //
        }
        fscanf(Fp1, "%s%s%s", label, opcode, operand);
       printf("while last \n");                                                         //
       // printf("%s %s %s\n", label, opcode, operand);                                                         //
    }
    fprintf(Fp2, "%s\t%s\t%s\n", label, opcode, operand);
    printf("end of prog\n");                                                         //
}
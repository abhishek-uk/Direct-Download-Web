#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
void main(){
    struct sockaddr_in server_addr;
    int socket_desp;
    char msg[10];
    socket_desp = socket(AF_INET, SOCK_DGRAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = 3000;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    bind(socket_desp, (struct sockaddr *)&server_addr, sizeof(server_addr));
    while(1){
        printf("\nclient:");
        scanf("%s", msg);
        sendto(socket_desp, msg, sizeof(msg), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
        if (!(strcmp(msg, "end")))
            break;
        recvfrom(socket_desp, msg, sizeof(msg), 0, NULL, NULL);
        printf("\nserver:%s", msg);
    }
}

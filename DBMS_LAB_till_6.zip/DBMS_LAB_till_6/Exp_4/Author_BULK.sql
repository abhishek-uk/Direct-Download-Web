insert into AUTHOR(Author_id, Name, Email, Phone_No, Status) values(1, "Mark Twain", "mark@gmail.com", "908765431", "Writing");

insert into AUTHOR(Author_id, Name, Email, Phone_No, Status) values(2, "Rowling", "rowling@gmail.com", "908765427", "Sleeping");

insert into AUTHOR(Author_id, Name, Email, Phone_No, Status) values(3, "Jane Austen", "jane@gmail.com", "908444434", "Not Writing");


